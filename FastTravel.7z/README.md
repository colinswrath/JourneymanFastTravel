Armorer is a plugin that adds tempering degredation to weapons and armor, as well as overhauling the names of tempered items.

## Tempering Degredation
** ---------------------** 

`Tempering on armor and weapons will now degrade over time with use`
`Temper on melee weapons will degrade when you hit an opponent.` 
`Bow/xbow temper will degrade anytime the bow is fired.`
**Armor will degrade when it is hit with a melee attack or arrow/bolt projectile as follows:**
	`Unblocked attacks will degrade all worn armor (besides shields) by the same amount`
	`If an attack is blocked, the shield or blocking weapon will take degredation hit instead of your armor`
	`If attacking with hand to hand attacks, tempering on your gauntlets (or other hand armor) will degrade`
	`Bashing with a shield/weapon will degrade your shield/weapon`
	`Power attacks will degrade both the target's armor/shield and the attacker's weapon by 1.5 times their normal rates`
	
There are options in the json file to adjust degredation rates

**License Disclaimer**
This DLL uses some code from my fork of "Improvement Names Customized" by FudgyDuff (aka. Ryan).
At the time I forked that mod, it was under an MIT license. 
Once one has received software under the original license, new license changes do not retroactivly remove those perms.

ie. I forked the mod when it was under MIT, therefore my fork retains the MIT permissions that it had at the time of creation.
Nevertheless, I have built a totally new mod and this is not a mere redistribution.

This mod is under the Apache 2.0 license.

## Building
```
 Clone the repository.
 Open the folder with Visual Studio.
 Choose the build-release-msvc option.
 Build.
```